package com.Productivity.productivity_website;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductivityWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
